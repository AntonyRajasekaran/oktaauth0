using EPiServer.DataAnnotations;

namespace Knights.Web.Features.Pages.PortalMfaChallenge;

[ContentType(
    DisplayName = "Portal MFA Challenge Page",
    GUID        = "D4E5F6A7-B8C9-0123-DEFA-234567890123",
    Description = "MFA challenge page for the portal — handles Guardian push and OTP fallback")]
public class PortalMfaChallengePage : PageData
{
    // Add CMS-editable properties here if needed
    // e.g. help text, support contact link
}
