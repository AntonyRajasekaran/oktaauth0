using EPiServer.DataAnnotations;

namespace Knights.Web.Features.Pages.PortalForgotPassword;

[ContentType(
    DisplayName = "Portal Forgot Password Page",
    GUID        = "C3D4E5F6-A7B8-9012-CDEF-123456789012",
    Description = "Forgot password page for the portal")]
public class PortalForgotPasswordPage : PageData
{
    // Add CMS-editable properties here if needed
}
