using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Services;
using Knights.Web.Models;

namespace Knights.Web.Features.Pages.PortalSignup;

public class PortalSignupPageController : PageController<PortalSignupPage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalSignupPageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalSignupPage currentContent)
    {
        // Already authenticated — go straight to portal
        if (User.Identity?.IsAuthenticated == true)
            return Redirect("/portal");

        return View(new PortalSignupPageViewModel(currentContent));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalSignupPage currentContent, SignupInputModel input)
    {
        if (!ModelState.IsValid)
        {
            return View(new PortalSignupPageViewModel(currentContent));
        }

        // 1. Create the account in Auth0
        var (_, signupError) = await _auth0.SignupAsync(new SignupRequest(
            input.Email,
            input.Password,
            input.GivenName,
            input.FamilyName));

        if (signupError is not null)
        {
            return View(new PortalSignupPageViewModel(currentContent)
            {
                ErrorMessage = signupError
            });
        }

        // 2. Immediately log the user in after signup
        var (token, loginError) = await _auth0.LoginAsync(input.Email, input.Password);

        if (loginError is not null)
        {
            // Account created but auto-login failed — redirect to login with message
            TempData["SignupSuccess"] = "Account created successfully! Please sign in.";
            return Redirect("/portal-login");
        }

        var claims = _claimsService.ParseIdToken(token!.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        // Store access token in cookie for use on subsequent pages
        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);

        return Redirect("/portal");
    }
}
