using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Features.Auth;

namespace Knights.Web.Features.Pages.Portal;

/// <summary>
/// Existing Optimizely content controller for /portal.
///
/// CHANGES FROM ORIGINAL:
///   1. [Authorize] scheme switched from "Auth0Portal" to "PortalCookies"
///   2. using Knights.Web.Features.Auth added at the top
///   3. BuildPortalUser() helper added
///
/// Everything else — PortalPage content model, view, existing logic — unchanged.
/// </summary>
public class PortalPageController : ContentController<PortalPage>
{
    // BEFORE:
    // [Authorize(AuthenticationSchemes = "Auth0Portal")]
    //
    // AFTER:
    [Authorize(AuthenticationSchemes = "PortalCookies")]
    public ActionResult Index(PortalPage currentPage)
    {
        var portalUser = BuildPortalUser();

        // Pass portalUser into your existing view model as needed.
        // Replace YourExistingViewModel with your actual model type.
        var model = new YourExistingViewModel(currentPage)
        {
            PortalUser = portalUser
            // ... your existing properties unchanged
        };

        return View(model);
    }

    // -------------------------------------------------------------------------
    // Add this helper to your existing controller body.
    // Reads claims that PortalClaimsService set during login.
    // -------------------------------------------------------------------------
    private PortalUserInfo BuildPortalUser()
    {
        var user       = HttpContext.User;
        var givenName  = user.FindFirstValue(ClaimTypes.GivenName) ?? string.Empty;
        var familyName = user.FindFirstValue(ClaimTypes.Surname)   ?? string.Empty;
        var fullName   = $"{givenName} {familyName}".Trim();

        var displayName = user.FindFirstValue(ClaimTypes.Name)
                       ?? (fullName.Length > 0 ? fullName : null)
                       ?? user.FindFirstValue(ClaimTypes.Email)
                       ?? "Portal User";

        return new PortalUserInfo
        {
            DisplayName = displayName,
            Email       = user.FindFirstValue(ClaimTypes.Email) ?? string.Empty,
            Roles       = user.Claims
                              .Where(c => c.Type == ClaimTypes.Role)
                              .Select(c => c.Value)
                              .ToList()
        };
    }
}
