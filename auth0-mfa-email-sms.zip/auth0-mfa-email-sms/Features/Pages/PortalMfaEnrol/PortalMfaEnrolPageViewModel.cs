using System.ComponentModel.DataAnnotations;
using EPiServer.Web.Mvc;

namespace Knights.Web.Features.Pages.PortalMfaEnrol;

public class PortalMfaEnrolPageViewModel : ContentViewModel<PortalMfaEnrolPage>
{
    public PortalMfaEnrolPageViewModel(PortalMfaEnrolPage currentContent)
        : base(currentContent) { }

    // Shown in the UI so user knows where the code was sent
    public string? MfaContact   { get; set; }   // email address or masked phone
    public string? MfaMethod    { get; set; }   // "Email" or "Sms"
    public string? ErrorMessage { get; set; }
}

public class MfaEnrolInputModel
{
    [Required(ErrorMessage = "Please enter the code")]
    [StringLength(6, MinimumLength = 6, ErrorMessage = "Code must be 6 digits")]
    public string Code { get; set; } = default!;

    // Carry mfa_token and oob_code through the form POST via hidden fields
    [Required]
    public string MfaToken { get; set; } = default!;

    [Required]
    public string OobCode { get; set; } = default!;
}
