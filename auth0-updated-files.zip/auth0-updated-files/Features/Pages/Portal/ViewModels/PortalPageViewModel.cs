namespace Knights.Web.Features.Pages.Portal.ViewModels
{
    public class PortalPageViewModel : ContentViewModel<PortalPage>
    {
        public PortalPageViewModel() : base() { }
        public PortalPageViewModel(PortalPage currentContent) : base(currentContent) { }

        public IReadOnlyList<string> Roles { get; set; } = [];
        public string DisplayName { get; set; } = string.Empty;
        public string Email       { get; set; } = string.Empty;
    }
}
