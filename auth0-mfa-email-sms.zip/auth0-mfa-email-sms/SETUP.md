# MFA Email / SMS OTP Setup Instructions

## Files in this zip

### REPLACE existing files:
- Models/Auth0Models.cs
- Services/Auth0AuthenticationService.cs
- Features/Pages/PortalLogin/PortalLoginPageController.cs
- Features/Pages/PortalSignup/PortalSignupPageViewModel.cs
- Features/Pages/PortalSignup/PortalSignupPageController.cs
- Features/Pages/PortalSignup/PortalSignupPage.cshtml
- Features/Pages/PortalMfaChallenge/PortalMfaChallengePageViewModel.cs
- Features/Pages/PortalMfaChallenge/PortalMfaChallengePageController.cs
- Features/Pages/PortalMfaChallenge/PortalMfaChallengePage.cshtml

### ADD new files:
- Features/Pages/PortalMfaEnrol/PortalMfaEnrolPage.cs
- Features/Pages/PortalMfaEnrol/PortalMfaEnrolPageViewModel.cs
- Features/Pages/PortalMfaEnrol/PortalMfaEnrolPageController.cs
- Features/Pages/PortalMfaEnrol/PortalMfaEnrolPage.cshtml

---

## Auth0 Dashboard Setup

1. Security -> Multi-factor Auth
   - Enable "Email" factor
   - Enable "SMS" factor
   - Set policy to "Always" (or "Optional" if you want skip for unenrolled users)

2. Applications -> Your App -> Settings -> Advanced -> Grant Types
   - Tick "MFA"
   - Save

---

## CMS Editor — create the enrolment page

Create a new page of type "Portal MFA Enrolment Page"
Set its URL to: /portal-mfa-enrol
Publish it

The existing "Portal MFA Challenge Page" at /portal-mfa stays unchanged.

---

## Full Flow

### First login after signup:
1. User fills in signup form, selects Email or SMS, enters phone if SMS
2. Account created in Auth0
3. Auto-login returns mfa_required + mfa_token
4. App calls /mfa/associate with chosen method
5. Auth0 sends OTP to email or phone
6. User redirected to /portal-mfa-enrol
7. User enters OTP -> enrolment confirmed -> signed in -> /portal

### Every subsequent login:
1. User submits email + password on /portal-login
2. Auth0 returns mfa_required + mfa_token
3. App calls /mfa/challenge -> Auth0 sends OTP to enrolled channel
4. User redirected to /portal-mfa
5. User enters OTP -> signed in -> /portal

---

## No Program.cs changes needed
The existing PortalCookies config and endpoint routing are unchanged.
