using EPiServer.DataAnnotations;

namespace Knights.Web.Features.Pages.PortalLogin;

[ContentType(
    DisplayName = "Portal Login Page",
    GUID        = "A1B2C3D4-E5F6-7890-ABCD-EF1234567890",
    Description = "Login page for the portal")]
public class PortalLoginPage : PageData
{
    // Add CMS-editable properties here if needed
    // e.g. intro text, logo override, etc.
}
