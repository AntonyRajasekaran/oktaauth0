using EPiServer.DataAnnotations;

namespace Knights.Web.Features.Pages.PortalMfaEnrol;

[ContentType(
    DisplayName = "Portal MFA Enrolment Page",
    GUID        = "E5F6A7B8-C9D0-1234-EFAB-345678901234",
    Description = "Confirms MFA enrolment after signup by verifying the OTP sent to email or SMS")]
public class PortalMfaEnrolPage : PageData
{
    // Add CMS-editable properties here if needed
}
