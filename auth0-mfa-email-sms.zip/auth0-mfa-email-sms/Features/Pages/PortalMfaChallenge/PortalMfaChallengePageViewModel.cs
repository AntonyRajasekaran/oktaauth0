using System.ComponentModel.DataAnnotations;
using EPiServer.Web.Mvc;

namespace Knights.Web.Features.Pages.PortalMfaChallenge;

public class PortalMfaChallengePageViewModel : ContentViewModel<PortalMfaChallengePage>
{
    public PortalMfaChallengePageViewModel(PortalMfaChallengePage currentContent)
        : base(currentContent) { }

    public string? ErrorMessage  { get; set; }

    // Shown in UI so user knows where the code was sent
    public string? OobChannel   { get; set; }   // "email" or "sms"
    public string? MfaToken     { get; set; }
    public string? OobCode      { get; set; }
}

public class MfaChallengeInputModel
{
    [Required(ErrorMessage = "Please enter the code")]
    [StringLength(6, MinimumLength = 6, ErrorMessage = "Code must be 6 digits")]
    public string Code { get; set; } = default!;

    [Required]
    public string MfaToken { get; set; } = default!;

    [Required]
    public string OobCode { get; set; } = default!;
}
