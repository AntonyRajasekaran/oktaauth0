using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Models;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalMfaChallenge;

public class PortalMfaChallengePageController : PageController<PortalMfaChallengePage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalMfaChallengePageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    // -------------------------------------------------------------------------
    // GET /portal-mfa
    // -------------------------------------------------------------------------
    [HttpGet]
    public IActionResult Index(PortalMfaChallengePage currentContent)
    {
        var mfaToken = TempData["MfaToken"] as string;
        var oobCode  = TempData["OobCode"]  as string;

        if (string.IsNullOrEmpty(mfaToken))
        {
            // No MFA token — user navigated here directly, send back to login
            return Redirect("/portal-login");
        }

        // Keep values alive for subsequent poll requests and OTP POST
        TempData.Keep("MfaToken");
        TempData.Keep("OobCode");

        return View("PortalMfaChallengePage",
            new PortalMfaChallengePageViewModel(currentContent)
            {
                MfaToken = mfaToken,
                OobCode  = oobCode
            });
    }

    // -------------------------------------------------------------------------
    // POST /portal-mfa/poll  (AJAX — called by JavaScript every 5 seconds)
    // Polls Auth0 to check if the user has approved the Guardian push.
    // Returns JSON so the client can handle approve/deny/pending states.
    // -------------------------------------------------------------------------
    [HttpPost("portal-mfa/poll")]
    [IgnoreAntiforgeryToken]   // AJAX endpoint — token passed via header instead
    public async Task<IActionResult> Poll()
    {
        var mfaToken = TempData["MfaToken"] as string;
        var oobCode  = TempData["OobCode"]  as string;

        // Keep alive for subsequent polls
        TempData.Keep("MfaToken");
        TempData.Keep("OobCode");

        if (string.IsNullOrEmpty(mfaToken) || string.IsNullOrEmpty(oobCode))
            return Json(new { status = "error",
                message = "Session expired. Please sign in again." });

        var (token, error) = await _auth0.PollMfaPushAsync(mfaToken, oobCode);

        return error switch
        {
            "authorization_pending" =>
                Json(new { status = "pending" }),

            "slow_down" =>
                Json(new { status = "slow_down" }),

            "access_denied" =>
                Json(new { status = "denied",
                    message = "Push notification was denied. Please try again." }),

            not null =>
                Json(new { status = "error", message = error }),

            _ => await ApproveAndSignInAsync(token!)
        };
    }

    // -------------------------------------------------------------------------
    // POST /portal-mfa  (OTP fallback form submission)
    // User enters 6-digit code from authenticator app instead of push.
    // -------------------------------------------------------------------------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalMfaChallengePage currentContent, MfaOtpInputModel input)
    {
        if (!ModelState.IsValid)
            return View("PortalMfaChallengePage",
                new PortalMfaChallengePageViewModel(currentContent)
                {
                    MfaToken = input.MfaToken
                });

        var (token, error) = await _auth0.VerifyMfaOtpAsync(input.MfaToken, input.Code);

        if (error is not null)
            return View("PortalMfaChallengePage",
                new PortalMfaChallengePageViewModel(currentContent)
                {
                    MfaToken     = input.MfaToken,
                    ErrorMessage = error
                });

        await SignInUserAsync(token!);
        return Redirect("/portal");
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private async Task<IActionResult> ApproveAndSignInAsync(Auth0TokenResponse token)
    {
        await SignInUserAsync(token);
        return Json(new { status = "approved", redirectUrl = "/portal" });
    }

    private async Task SignInUserAsync(Auth0TokenResponse token)
    {
        var claims = _claimsService.ParseIdToken(token.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);
    }
}
