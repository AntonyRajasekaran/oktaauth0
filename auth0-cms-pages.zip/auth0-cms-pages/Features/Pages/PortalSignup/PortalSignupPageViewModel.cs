using System.ComponentModel.DataAnnotations;
using EPiServer.Web.Mvc;

namespace Knights.Web.Features.Pages.PortalSignup;

public class PortalSignupPageViewModel : ContentViewModel<PortalSignupPage>
{
    public PortalSignupPageViewModel(PortalSignupPage currentContent)
        : base(currentContent) { }

    public string? ErrorMessage { get; set; }
}

public class SignupInputModel
{
    [Required(ErrorMessage = "First name is required")]
    [Display(Name = "First name")]
    public string GivenName { get; set; } = default!;

    [Required(ErrorMessage = "Last name is required")]
    [Display(Name = "Last name")]
    public string FamilyName { get; set; } = default!;

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Enter a valid email address")]
    public string Email { get; set; } = default!;

    [Required(ErrorMessage = "Password is required")]
    [MinLength(8, ErrorMessage = "Password must be at least 8 characters")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = default!;

    [Required(ErrorMessage = "Please confirm your password")]
    [DataType(DataType.Password)]
    [Compare(nameof(Password), ErrorMessage = "Passwords do not match.")]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = default!;
}
