using System.ComponentModel.DataAnnotations;
using EPiServer.Web.Mvc;

namespace Knights.Web.Features.Pages.PortalLogin;

public class PortalLoginPageViewModel : ContentViewModel<PortalLoginPage>
{
    public PortalLoginPageViewModel(PortalLoginPage currentContent)
        : base(currentContent) { }

    public string? ErrorMessage   { get; set; }
    public string? SuccessMessage { get; set; }
}

public class LoginInputModel
{
    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Enter a valid email address")]
    public string Email { get; set; } = default!;

    [Required(ErrorMessage = "Password is required")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = default!;

    [Display(Name = "Remember me")]
    public bool RememberMe { get; set; }
}
