using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalLogin;

public class PortalLoginPageController : PageController<PortalLoginPage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalLoginPageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalLoginPage currentContent)
    {
        // Already authenticated — go straight to portal
        if (User.Identity?.IsAuthenticated == true)
            return Redirect("/portal");

        var model = new PortalLoginPageViewModel(currentContent)
        {
            SuccessMessage = TempData["SignupSuccess"] as string
        };

        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalLoginPage currentContent, LoginInputModel input)
    {
        if (!ModelState.IsValid)
        {
            return View(new PortalLoginPageViewModel(currentContent));
        }

        var (token, error) = await _auth0.LoginAsync(input.Email, input.Password);

        if (error is not null)
        {
            return View(new PortalLoginPageViewModel(currentContent)
            {
                ErrorMessage = error
            });
        }

        var claims = _claimsService.ParseIdToken(token!.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = input.RememberMe,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        // Store access token in cookie for use on subsequent pages
        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);

        return Redirect("/portal");
    }
}
