using System.ComponentModel.DataAnnotations;
using EPiServer.Web.Mvc;

namespace Knights.Web.Features.Pages.PortalMfaChallenge;

public class PortalMfaChallengePageViewModel : ContentViewModel<PortalMfaChallengePage>
{
    public PortalMfaChallengePageViewModel(PortalMfaChallengePage currentContent)
        : base(currentContent) { }

    public string? ErrorMessage { get; set; }

    // Passed to the view so the OTP form and poll endpoint have access
    public string? MfaToken { get; set; }
    public string? OobCode  { get; set; }
}

/// <summary>
/// Used by the OTP fallback form POST when user enters authenticator code.
/// </summary>
public class MfaOtpInputModel
{
    [Required(ErrorMessage = "Please enter the code")]
    [StringLength(6, MinimumLength = 6, ErrorMessage = "Code must be 6 digits")]
    public string Code { get; set; } = default!;

    [Required]
    public string MfaToken { get; set; } = default!;
}
