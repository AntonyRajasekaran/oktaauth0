using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Knights.Web.Models;

namespace Knights.Web.Services;

public interface IAuth0AuthenticationService
{
    // Returns (Token, Error, MfaToken) — MfaToken set when error == "mfa_required"
    Task<(Auth0TokenResponse? Token, string? Error, string? MfaToken)> LoginAsync(
        string email, string password);

    Task<(Auth0SignupResponse? User, string? Error)> SignupAsync(SignupRequest request);
    Task<(bool Success, string? Error)> ForgotPasswordAsync(string email);

    // MFA enrolment — called after signup auto-login returns mfa_required
    Task<(Auth0MfaAssociateResponse? Association, string? Error)> AssociateMfaAsync(
        string mfaToken, MfaMethod method, string? phoneNumber = null);

    // MFA challenge — called on every login when mfa_required
    Task<(Auth0MfaChallengeResponse? Challenge, string? Error)> RequestMfaChallengeAsync(
        string mfaToken);

    // Verify OTP — used for both enrolment confirmation and login challenge
    Task<(Auth0TokenResponse? Token, string? Error)> VerifyMfaOobAsync(
        string mfaToken, string oobCode, string otpCode);
}

public class Auth0AuthenticationService : IAuth0AuthenticationService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _config;
    private readonly ILogger<Auth0AuthenticationService> _logger;

    private string Domain       => _config["Auth0:Domain"]!;
    private string ClientId     => _config["Auth0:ClientId"]!;
    private string ClientSecret => _config["Auth0:ClientSecret"]!;
    private string Audience     => _config["Auth0:Audience"]!;
    private string Connection   => _config["Auth0:Connection"]
                                   ?? "Username-Password-Authentication";

    public Auth0AuthenticationService(
        HttpClient httpClient,
        IConfiguration config,
        ILogger<Auth0AuthenticationService> logger)
    {
        _httpClient = httpClient;
        _config     = config;
        _logger     = logger;
    }

    // -------------------------------------------------------------------------
    // LOGIN
    // -------------------------------------------------------------------------
    public async Task<(Auth0TokenResponse? Token, string? Error, string? MfaToken)>
        LoginAsync(string email, string password)
    {
        var payload = new Dictionary<string, string>
        {
            ["grant_type"]    = "password",
            ["username"]      = email,
            ["password"]      = password,
            ["audience"]      = Audience,
            ["scope"]         = "openid profile email",
            ["client_id"]     = ClientId,
            ["client_secret"] = ClientSecret
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/oauth/token",
                new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0TokenResponse>(json);
                return (result, null, null);
            }

            // Check for mfa_required — return mfa_token to caller
            var mfaResponse = JsonSerializer.Deserialize<Auth0MfaRequiredResponse>(json);
            if (mfaResponse?.Error == "mfa_required")
                return (null, "mfa_required", mfaResponse.MfaToken);

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [\"{Code}\"]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (null, errorMessage, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 login request failed");
            return (null, "An unexpected error occurred. Please try again.", null);
        }
    }

    // -------------------------------------------------------------------------
    // SIGNUP
    // -------------------------------------------------------------------------
    public async Task<(Auth0SignupResponse? User, string? Error)> SignupAsync(
        SignupRequest request)
    {
        var payload = new
        {
            client_id     = ClientId,
            email         = request.Email,
            password      = request.Password,
            connection    = Connection,
            name          = $"{request.GivenName} {request.FamilyName}",
            user_metadata = new
            {
                given_name  = request.GivenName,
                family_name = request.FamilyName
            }
        };

        try
        {
            var response = await _httpClient.PostAsJsonAsync(
                $"https://{Domain}/dbconnections/signup", payload);

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0SignupResponse>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [\"{Code}\"]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (default, errorMessage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 signup request failed");
            return (default, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // FORGOT PASSWORD
    // -------------------------------------------------------------------------
    public async Task<(bool Success, string? Error)> ForgotPasswordAsync(string email)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]  = ClientId,
            ["email"]      = email,
            ["connection"] = Connection
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/dbconnections/change_password",
                new FormUrlEncodedContent(payload));

            if (response.IsSuccessStatusCode) return (true, null);

            var error = await ParseErrorAsync(response);
            _logger.LogWarning("Auth0 forgot password error: {Error}", error);
            return (false, error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 forgot password request failed");
            return (false, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // MFA ENROLMENT — associates email or SMS as the MFA method for a new user
    // Called immediately after signup auto-login returns mfa_required.
    // Auth0 sends an OTP to the chosen channel to confirm enrolment.
    // -------------------------------------------------------------------------
    public async Task<(Auth0MfaAssociateResponse? Association, string? Error)>
        AssociateMfaAsync(string mfaToken, MfaMethod method, string? phoneNumber = null)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]            = ClientId,
            ["client_secret"]        = ClientSecret,
            ["authenticator_type"]   = "oob",
            ["oob_channels"]         = method == MfaMethod.Sms ? "sms" : "email"
        };

        if (method == MfaMethod.Sms && !string.IsNullOrEmpty(phoneNumber))
            payload["phone_number"] = phoneNumber;

        try
        {
            var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"https://{Domain}/mfa/associate");

            // mfa_token goes in the Authorization header for enrolment
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer", mfaToken);

            request.Content = new FormUrlEncodedContent(payload);

            var response = await _httpClient.SendAsync(request);
            var json     = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0MfaAssociateResponse>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            return (null, MapError(errorResponse?.Error, errorResponse?.ErrorDescription));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 MFA association request failed");
            return (null, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // MFA CHALLENGE — triggers Auth0 to send an OTP via the user's enrolled method
    // Called on every login when mfa_required is returned
    // -------------------------------------------------------------------------
    public async Task<(Auth0MfaChallengeResponse? Challenge, string? Error)>
        RequestMfaChallengeAsync(string mfaToken)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]      = ClientId,
            ["client_secret"]  = ClientSecret,
            ["mfa_token"]      = mfaToken,
            ["challenge_type"] = "oob"
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/mfa/challenge",
                new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0MfaChallengeResponse>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);

            // association_required = user not enrolled — caller handles
            if (errorResponse?.Error == "association_required")
                return (null, "association_required");

            return (null, MapError(errorResponse?.Error, errorResponse?.ErrorDescription));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 MFA challenge request failed");
            return (null, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // VERIFY OTP — verifies the OTP code for both enrolment and login challenge
    // Uses the mfa-oob grant type with the oob_code from the challenge/associate
    // -------------------------------------------------------------------------
    public async Task<(Auth0TokenResponse? Token, string? Error)> VerifyMfaOobAsync(
        string mfaToken, string oobCode, string otpCode)
    {
        var payload = new Dictionary<string, string>
        {
            ["grant_type"]    = "http://auth0.com/oauth/grant-type/mfa-oob",
            ["client_id"]     = ClientId,
            ["client_secret"] = ClientSecret,
            ["mfa_token"]     = mfaToken,
            ["oob_code"]      = oobCode,
            ["binding_code"]  = otpCode   // the OTP the user received
        };

        return await PostAsync<Auth0TokenResponse>(
            $"https://{Domain}/oauth/token", payload);
    }

    // -------------------------------------------------------------------------
    // Shared helpers
    // -------------------------------------------------------------------------
    private async Task<(T? Result, string? Error)> PostAsync<T>(
        string url, Dictionary<string, string> payload)
    {
        try
        {
            var response = await _httpClient.PostAsync(
                url, new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<T>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [\"{Code}\"]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (default, errorMessage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 API request to {Url} failed", url);
            return (default, "An unexpected error occurred. Please try again.");
        }
    }

    private static async Task<string> ParseErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var json  = await response.Content.ReadAsStringAsync();
            var error = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            return MapError(error?.Error, error?.ErrorDescription);
        }
        catch
        {
            return "An unexpected error occurred.";
        }
    }

    private static string MapError(string? code, string? description) => code switch
    {
        "invalid_grant"         => "Incorrect email or password.",
        "invalid_user_password" => "Incorrect email or password.",
        "too_many_attempts"     => "Account locked due to too many failed attempts. Check your email to unlock.",
        "user_exists"           => "An account with this email already exists.",
        "invalid_password"      => description ?? "Password does not meet requirements.",
        "invalid_signup"        => "Signup is not available at this time.",
        "unauthorized_client"   => "Authentication is not configured correctly.",
        "invalid_otp"           => "Incorrect code. Please try again.",
        "invalid_binding_code"  => "Incorrect code. Please try again.",
        "expired_token"         => "Your session has expired. Please sign in again.",
        _                       => "Something went wrong. Please try again."
    };
}
