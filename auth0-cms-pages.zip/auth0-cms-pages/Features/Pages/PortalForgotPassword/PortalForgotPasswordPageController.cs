using Microsoft.AspNetCore.Mvc;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalForgotPassword;

public class PortalForgotPasswordPageController : PageController<PortalForgotPasswordPage>
{
    private readonly IAuth0AuthenticationService _auth0;

    public PortalForgotPasswordPageController(IAuth0AuthenticationService auth0)
    {
        _auth0 = auth0;
    }

    [HttpGet]
    public IActionResult Index(PortalForgotPasswordPage currentContent)
    {
        return View(new PortalForgotPasswordPageViewModel(currentContent));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalForgotPasswordPage currentContent, ForgotPasswordInputModel input)
    {
        if (!ModelState.IsValid)
        {
            return View(new PortalForgotPasswordPageViewModel(currentContent));
        }

        var (success, error) = await _auth0.ForgotPasswordAsync(input.Email);

        if (!success && error is not null)
        {
            // Only surface hard config-level errors.
            // Auth0 returns 200 for unknown emails to prevent enumeration.
            return View(new PortalForgotPasswordPageViewModel(currentContent)
            {
                ErrorMessage = error
            });
        }

        // Always show confirmation — never reveal whether the email exists
        return View(new PortalForgotPasswordPageViewModel(currentContent)
        {
            EmailSent = true,
            Email     = input.Email
        });
    }
}
