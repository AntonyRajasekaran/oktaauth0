using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Models;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalLogin;

public class PortalLoginPageController : PageController<PortalLoginPage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalLoginPageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalLoginPage currentContent)
    {
        if (User.Identity?.IsAuthenticated == true)
            return Redirect("/portal");

        var model = new PortalLoginPageViewModel(currentContent)
        {
            SuccessMessage = TempData["SignupSuccess"] as string
        };

        return View("PortalLoginPage", model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalLoginPage currentContent, LoginInputModel input)
    {
        if (!ModelState.IsValid)
            return View("PortalLoginPage",
                new PortalLoginPageViewModel(currentContent));

        var (token, error, mfaToken) = await _auth0.LoginAsync(
            input.Email, input.Password);

        // -------------------------------------------------------------------
        // MFA required — request challenge (sends OTP via enrolled channel)
        // -------------------------------------------------------------------
        if (error == "mfa_required")
        {
            var (challenge, challengeError) =
                await _auth0.RequestMfaChallengeAsync(mfaToken!);

            if (challengeError == "association_required")
            {
                // User not enrolled — skip MFA and sign in directly
                // This handles the edge case where MFA policy is "optional"
                // For "always" policy this branch should not be reached
                var (directToken, directError, _) =
                    await _auth0.LoginAsync(input.Email, input.Password);

                if (directToken is not null)
                {
                    await SignInUserAsync(directToken);
                    return Redirect("/portal");
                }

                return View("PortalLoginPage",
                    new PortalLoginPageViewModel(currentContent)
                    {
                        ErrorMessage = directError
                    });
            }

            if (challengeError is not null)
                return View("PortalLoginPage",
                    new PortalLoginPageViewModel(currentContent)
                    {
                        ErrorMessage = challengeError
                    });

            // Store context for the MFA challenge page
            TempData["MfaToken"]   = mfaToken;
            TempData["OobCode"]    = challenge!.OobCode;
            TempData["OobChannel"] = challenge.OobChannel; // "email" or "sms"

            return Redirect("/portal-mfa");
        }

        if (error is not null)
            return View("PortalLoginPage",
                new PortalLoginPageViewModel(currentContent)
                {
                    ErrorMessage = error
                });

        await SignInUserAsync(token!);
        return Redirect("/portal");
    }

    private async Task SignInUserAsync(Auth0TokenResponse token)
    {
        var claims = _claimsService.ParseIdToken(token.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);
    }
}
