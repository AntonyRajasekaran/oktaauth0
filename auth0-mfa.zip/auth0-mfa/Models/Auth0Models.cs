using System.Text.Json.Serialization;

namespace Knights.Web.Models;

public record LoginRequest(string Email, string Password);

public record SignupRequest(
    string Email,
    string Password,
    string GivenName,
    string FamilyName);

public record ForgotPasswordRequest(string Email);

public record Auth0TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; init; } = default!;

    [JsonPropertyName("id_token")]
    public string IdToken { get; init; } = default!;

    [JsonPropertyName("token_type")]
    public string TokenType { get; init; } = default!;

    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; init; }
}

public record Auth0ErrorResponse
{
    [JsonPropertyName("error")]
    public string Error { get; init; } = default!;

    [JsonPropertyName("error_description")]
    public string ErrorDescription { get; init; } = default!;
}

public record Auth0SignupResponse
{
    [JsonPropertyName("_id")]
    public string Id { get; init; } = default!;

    [JsonPropertyName("email")]
    public string Email { get; init; } = default!;

    [JsonPropertyName("email_verified")]
    public bool EmailVerified { get; init; }
}

// -------------------------------------------------------------------------
// MFA Models
// -------------------------------------------------------------------------

/// <summary>
/// Returned by Auth0 when MFA is required after password grant.
/// Contains the mfa_token needed for subsequent MFA challenge calls.
/// </summary>
public record Auth0MfaRequiredResponse
{
    [JsonPropertyName("error")]
    public string Error { get; init; } = default!;

    [JsonPropertyName("mfa_token")]
    public string MfaToken { get; init; } = default!;
}

/// <summary>
/// Returned by Auth0 /mfa/challenge endpoint.
/// For oob (Guardian push): contains oob_code used when polling.
/// For association_required: user is not enrolled — skip MFA.
/// </summary>
public record Auth0MfaChallengeResponse
{
    [JsonPropertyName("challenge_type")]
    public string ChallengeType { get; init; } = default!;

    // Returned for oob (push) challenges — required when polling /oauth/token
    [JsonPropertyName("oob_code")]
    public string? OobCode { get; init; }

    // Present when an error occurs e.g. association_required
    [JsonPropertyName("error")]
    public string? Error { get; init; }

    [JsonPropertyName("error_description")]
    public string? ErrorDescription { get; init; }
}
