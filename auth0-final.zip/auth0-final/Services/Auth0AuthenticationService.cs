using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Knights.Web.Models;

namespace Knights.Web.Services;

public interface IAuth0AuthenticationService
{
    Task<(Auth0TokenResponse? Token, string? Error)> LoginAsync(string email, string password);
    Task<(Auth0SignupResponse? User, string? Error)> SignupAsync(SignupRequest request);
    Task<(bool Success, string? Error)> ForgotPasswordAsync(string email);
}

public class Auth0AuthenticationService : IAuth0AuthenticationService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _config;
    private readonly ILogger<Auth0AuthenticationService> _logger;

    private string Domain     => _config["Auth0:Domain"]!;
    private string ClientId   => _config["Auth0:ClientId"]!;
    private string ClientSecret => _config["Auth0:ClientSecret"]!;
    private string Audience   => _config["Auth0:Audience"]!;
    private string Connection => _config["Auth0:Connection"] ?? "Username-Password-Authentication";

    public Auth0AuthenticationService(
        HttpClient httpClient,
        IConfiguration config,
        ILogger<Auth0AuthenticationService> logger)
    {
        _httpClient = httpClient;
        _config     = config;
        _logger     = logger;
    }

    // -------------------------------------------------------------------------
    // LOGIN — Resource Owner Password Grant
    // Requires "Password" grant enabled on your Auth0 application
    // -------------------------------------------------------------------------
    public async Task<(Auth0TokenResponse? Token, string? Error)> LoginAsync(
        string email, string password)
    {
        var payload = new Dictionary<string, string>
        {
            ["grant_type"]    = "password",
            ["username"]      = email,
            ["password"]      = password,
            ["audience"]      = Audience,
            ["scope"]         = "openid profile email",
            ["client_id"]     = ClientId,
            ["client_secret"] = ClientSecret
        };

        return await PostAsync<Auth0TokenResponse>(
            $"https://{Domain}/oauth/token", payload);
    }

    // -------------------------------------------------------------------------
    // SIGNUP — Auth0 DB Connection signup endpoint
    // Does NOT log the user in — LoginAsync is called after successful signup
    // -------------------------------------------------------------------------
    public async Task<(Auth0SignupResponse? User, string? Error)> SignupAsync(
        SignupRequest request)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]     = ClientId,
            ["email"]         = request.Email,
            ["password"]      = request.Password,
            ["connection"]    = Connection,
            ["name"]          = $"{request.GivenName} {request.FamilyName}",
            ["user_metadata"] = JsonSerializer.Serialize(new
            {
                given_name  = request.GivenName,
                family_name = request.FamilyName
            })
        };

        return await PostAsync<Auth0SignupResponse>(
            $"https://{Domain}/dbconnections/signup", payload);
    }

    // -------------------------------------------------------------------------
    // FORGOT PASSWORD — Triggers Auth0 password reset email
    // Always returns success to the user (to prevent email enumeration)
    // -------------------------------------------------------------------------
    public async Task<(bool Success, string? Error)> ForgotPasswordAsync(string email)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]  = ClientId,
            ["email"]      = email,
            ["connection"] = Connection
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/dbconnections/change_password",
                new FormUrlEncodedContent(payload));

            if (response.IsSuccessStatusCode) return (true, null);

            var error = await ParseErrorAsync(response);
            _logger.LogWarning("Auth0 forgot password error: {Error}", error);
            return (false, error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 forgot password request failed");
            return (false, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // Shared helpers
    // -------------------------------------------------------------------------
    private async Task<(T? Result, string? Error)> PostAsync<T>(
        string url, Dictionary<string, string> payload)
    {
        try
        {
            var response = await _httpClient.PostAsync(
                url, new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<T>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [{Code}]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (default, errorMessage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 API request to {Url} failed", url);
            return (default, "An unexpected error occurred. Please try again.");
        }
    }

    private static async Task<string> ParseErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var json  = await response.Content.ReadAsStringAsync();
            var error = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            return MapError(error?.Error, error?.ErrorDescription);
        }
        catch
        {
            return "An unexpected error occurred.";
        }
    }

    private static string MapError(string? code, string? description) => code switch
    {
        "invalid_grant"         => "Incorrect email or password.",
        "invalid_user_password" => "Incorrect email or password.",
        "too_many_attempts"     => "Account locked due to too many failed attempts. Check your email to unlock.",
        "user_exists"           => "An account with this email already exists.",
        "invalid_password"      => description ?? "Password does not meet requirements.",
        "invalid_signup"        => "Signup is not available at this time.",
        "unauthorized_client"   => "Authentication is not configured correctly.",
        _                       => "Something went wrong. Please try again."
    };
}
