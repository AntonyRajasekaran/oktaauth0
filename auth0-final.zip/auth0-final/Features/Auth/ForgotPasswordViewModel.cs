using System.ComponentModel.DataAnnotations;

namespace Knights.Web.Features.Auth;

public class ForgotPasswordViewModel
{
    [Required, EmailAddress]
    public string Email { get; set; } = default!;

    public bool    EmailSent    { get; set; }
    public string? ErrorMessage { get; set; }
}
