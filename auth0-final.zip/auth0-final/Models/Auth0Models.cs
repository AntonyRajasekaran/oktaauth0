using System.Text.Json.Serialization;

namespace Knights.Web.Models;

public record LoginRequest(string Email, string Password);

public record SignupRequest(
    string Email,
    string Password,
    string GivenName,
    string FamilyName);

public record ForgotPasswordRequest(string Email);

public record Auth0TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; init; } = default!;

    [JsonPropertyName("id_token")]
    public string IdToken { get; init; } = default!;

    [JsonPropertyName("token_type")]
    public string TokenType { get; init; } = default!;

    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; init; }
}

public record Auth0ErrorResponse
{
    [JsonPropertyName("error")]
    public string Error { get; init; } = default!;

    [JsonPropertyName("error_description")]
    public string ErrorDescription { get; init; } = default!;
}

public record Auth0SignupResponse
{
    [JsonPropertyName("_id")]
    public string Id { get; init; } = default!;

    [JsonPropertyName("email")]
    public string Email { get; init; } = default!;

    [JsonPropertyName("email_verified")]
    public bool EmailVerified { get; init; }
}
