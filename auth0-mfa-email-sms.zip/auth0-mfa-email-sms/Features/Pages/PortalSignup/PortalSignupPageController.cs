using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Models;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalSignup;

public class PortalSignupPageController : PageController<PortalSignupPage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalSignupPageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalSignupPage currentContent)
    {
        if (User.Identity?.IsAuthenticated == true)
            return Redirect("/portal");

        return View("PortalSignupPage",
            new PortalSignupPageViewModel(currentContent));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalSignupPage currentContent, SignupInputModel input)
    {
        // Server-side validation: phone number required for SMS method
        if (input.MfaMethod == MfaMethod.Sms &&
            string.IsNullOrWhiteSpace(input.PhoneNumber))
        {
            ModelState.AddModelError(
                nameof(input.PhoneNumber),
                "Mobile number is required for SMS verification.");
        }

        if (!ModelState.IsValid)
            return View("PortalSignupPage",
                new PortalSignupPageViewModel(currentContent));

        // 1. Create the account in Auth0
        var (_, signupError) = await _auth0.SignupAsync(new SignupRequest(
            input.Email,
            input.Password,
            input.GivenName,
            input.FamilyName));

        if (signupError is not null)
            return View("PortalSignupPage",
                new PortalSignupPageViewModel(currentContent)
                {
                    ErrorMessage = signupError
                });

        // 2. Auto-login — will return mfa_required + mfa_token for new user
        var (_, loginError, mfaToken) =
            await _auth0.LoginAsync(input.Email, input.Password);

        if (loginError is not null && loginError != "mfa_required")
        {
            // Login failed for a reason other than MFA — redirect to login
            TempData["SignupSuccess"] = "Account created! Please sign in.";
            return Redirect("/portal-login");
        }

        if (string.IsNullOrEmpty(mfaToken))
        {
            // MFA not enforced on this tenant — sign in directly
            var (directToken, directError, _) =
                await _auth0.LoginAsync(input.Email, input.Password);

            if (directToken is not null)
            {
                await SignInUserAsync(directToken);
                return Redirect("/portal");
            }

            TempData["SignupSuccess"] = "Account created! Please sign in.";
            return Redirect("/portal-login");
        }

        // 3. Enrol the chosen MFA method
        //    Auth0 sends an OTP to email or phone to confirm enrolment
        var (association, enrolError) = await _auth0.AssociateMfaAsync(
            mfaToken,
            input.MfaMethod,
            input.PhoneNumber);

        if (enrolError is not null)
            return View("PortalSignupPage",
                new PortalSignupPageViewModel(currentContent)
                {
                    ErrorMessage = enrolError
                });

        // 4. Store enrolment context in TempData for the enrolment OTP page
        TempData["MfaToken"]     = mfaToken;
        TempData["OobCode"]      = association!.OobCode;
        TempData["MfaMethod"]    = input.MfaMethod.ToString();
        TempData["MfaContact"]   = input.MfaMethod == MfaMethod.Sms
            ? input.PhoneNumber
            : input.Email;

        return Redirect("/portal-mfa-enrol");
    }

    private async Task SignInUserAsync(Auth0TokenResponse token)
    {
        var claims = _claimsService.ParseIdToken(token.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);
    }
}
