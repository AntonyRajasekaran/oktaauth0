using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Models;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalMfaChallenge;

/// <summary>
/// Handles the MFA challenge on every login.
/// Auth0 sends an OTP to the user's enrolled email or SMS channel.
/// User enters the code here to complete sign in.
/// </summary>
public class PortalMfaChallengePageController : PageController<PortalMfaChallengePage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalMfaChallengePageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalMfaChallengePage currentContent)
    {
        var mfaToken  = TempData["MfaToken"]  as string;
        var oobCode   = TempData["OobCode"]   as string;
        var oobChannel = TempData["OobChannel"] as string;

        if (string.IsNullOrEmpty(mfaToken))
            return Redirect("/portal-login");

        TempData.Keep("MfaToken");
        TempData.Keep("OobCode");
        TempData.Keep("OobChannel");

        return View("PortalMfaChallengePage",
            new PortalMfaChallengePageViewModel(currentContent)
            {
                MfaToken   = mfaToken,
                OobCode    = oobCode,
                OobChannel = oobChannel
            });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalMfaChallengePage currentContent, MfaChallengeInputModel input)
    {
        var oobChannel = TempData["OobChannel"] as string;

        if (!ModelState.IsValid)
            return View("PortalMfaChallengePage",
                new PortalMfaChallengePageViewModel(currentContent)
                {
                    MfaToken   = input.MfaToken,
                    OobCode    = input.OobCode,
                    OobChannel = oobChannel
                });

        var (token, error) = await _auth0.VerifyMfaOobAsync(
            input.MfaToken, input.OobCode, input.Code);

        if (error is not null)
            return View("PortalMfaChallengePage",
                new PortalMfaChallengePageViewModel(currentContent)
                {
                    MfaToken     = input.MfaToken,
                    OobCode      = input.OobCode,
                    OobChannel   = oobChannel,
                    ErrorMessage = error
                });

        await SignInUserAsync(token!);
        return Redirect("/portal");
    }

    private async Task SignInUserAsync(Auth0TokenResponse token)
    {
        var claims = _claimsService.ParseIdToken(token.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);
    }
}
