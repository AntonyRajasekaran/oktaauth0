namespace Knights.Web.Features.Auth;

public class PortalUserInfo
{
    public string DisplayName { get; init; } = default!;
    public string Email       { get; init; } = default!;
    public IReadOnlyList<string> Roles { get; init; } = Array.Empty<string>();

    public bool IsInRole(string role) =>
        Roles.Contains(role, StringComparer.OrdinalIgnoreCase);
}
