using EPiServer.DataAnnotations;

namespace Knights.Web.Features.Pages.PortalSignup;

[ContentType(
    DisplayName = "Portal Signup Page",
    GUID        = "B2C3D4E5-F6A7-8901-BCDE-F12345678901",
    Description = "Signup page for the portal")]
public class PortalSignupPage : PageData
{
    // Add CMS-editable properties here if needed
}
