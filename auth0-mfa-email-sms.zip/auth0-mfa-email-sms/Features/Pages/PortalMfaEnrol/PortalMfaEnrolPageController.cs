using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Models;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalMfaEnrol;

/// <summary>
/// Handles MFA enrolment confirmation after signup.
/// The user has chosen email or SMS on the signup page.
/// Auth0 sent an OTP to confirm — the user enters it here.
/// After successful verification the user is signed in and
/// redirected to /portal.
/// </summary>
public class PortalMfaEnrolPageController : PageController<PortalMfaEnrolPage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalMfaEnrolPageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalMfaEnrolPage currentContent)
    {
        var mfaToken   = TempData["MfaToken"]   as string;
        var oobCode    = TempData["OobCode"]    as string;
        var mfaMethod  = TempData["MfaMethod"]  as string;
        var mfaContact = TempData["MfaContact"] as string;

        if (string.IsNullOrEmpty(mfaToken) || string.IsNullOrEmpty(oobCode))
            return Redirect("/portal-login");

        // Keep values alive for the POST
        TempData.Keep("MfaToken");
        TempData.Keep("OobCode");
        TempData.Keep("MfaMethod");
        TempData.Keep("MfaContact");

        return View("PortalMfaEnrolPage",
            new PortalMfaEnrolPageViewModel(currentContent)
            {
                MfaMethod  = mfaMethod,
                MfaContact = mfaContact
            });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalMfaEnrolPage currentContent, MfaEnrolInputModel input)
    {
        var mfaMethod  = TempData["MfaMethod"]  as string;
        var mfaContact = TempData["MfaContact"] as string;

        if (!ModelState.IsValid)
            return View("PortalMfaEnrolPage",
                new PortalMfaEnrolPageViewModel(currentContent)
                {
                    MfaMethod  = mfaMethod,
                    MfaContact = mfaContact
                });

        // Verify the OTP code — this confirms enrolment and returns real tokens
        var (token, error) = await _auth0.VerifyMfaOobAsync(
            input.MfaToken, input.OobCode, input.Code);

        if (error is not null)
            return View("PortalMfaEnrolPage",
                new PortalMfaEnrolPageViewModel(currentContent)
                {
                    MfaMethod    = mfaMethod,
                    MfaContact   = mfaContact,
                    ErrorMessage = error
                });

        // Enrolment confirmed — sign the user in
        await SignInUserAsync(token!);
        return Redirect("/portal");
    }

    private async Task SignInUserAsync(Auth0TokenResponse token)
    {
        var claims = _claimsService.ParseIdToken(token.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);
    }
}
