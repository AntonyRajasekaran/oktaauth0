using EPiServer.Web;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Features.Pages.Portal.ViewModels;

namespace Knights.Web.Features.Pages.Portal;

/// <summary>
/// Serves the main /portal CMS page and handles logout.
/// Logout is here rather than a separate controller to avoid
/// Optimizely's MapContent() intercepting a dedicated logout route.
/// </summary>
[Authorize(AuthenticationSchemes = "PortalCookies")]
public class PortalPageController : PageController<PortalPage>
{
    private readonly IContextModeResolver _contextMode;
    private readonly IConfiguration _config;

    public PortalPageController(
        IContextModeResolver contextMode,
        IConfiguration config)
    {
        _contextMode = contextMode;
        _config      = config;
    }

    [HttpGet]
    public IActionResult Index(PortalPage currentContent)
    {
        var givenName  = User.FindFirstValue(ClaimTypes.GivenName) ?? string.Empty;
        var familyName = User.FindFirstValue(ClaimTypes.Surname)   ?? string.Empty;
        var fullName   = $"{givenName} {familyName}".Trim();

        var displayName = User.FindFirstValue(ClaimTypes.Name)
                       ?? (fullName.Length > 0 ? fullName : null)
                       ?? User.FindFirstValue(ClaimTypes.Email)
                       ?? "Portal User";

        var roles = User.FindAll(ClaimTypes.Role)
                        .Select(c => c.Value)
                        .ToList();

        return View("PortalPage", new PortalPageViewModel(currentContent)
        {
            DisplayName = displayName,
            Email       = User.FindFirstValue(ClaimTypes.Email) ?? string.Empty,
            Roles       = roles
        });
    }

    // -------------------------------------------------------------------------
    // POST /portal/logout
    // Logout lives here so it resolves under the /portal CMS content route
    // which Optimizely already owns — no separate controller or route needed.
    // -------------------------------------------------------------------------
    [HttpPost("portal/logout")]
    [AutoValidateAntiforgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync("PortalCookies");

        var domain   = _config["Auth0:Domain"];
        var clientId = _config["Auth0:ClientId"];
        var returnTo = Uri.EscapeDataString(
            $"{Request.Scheme}://{Request.Host}/portal-login");

        return Redirect(
            $"https://{domain}/v2/logout?client_id={clientId}&returnTo={returnTo}");
    }
}
