// ============================================================
// MFA SETUP INSTRUCTIONS
// ============================================================


// ------------------------------------------------------------
// 1. FILES — what to do with each file in this zip
// ------------------------------------------------------------

// REPLACE existing files:
//   Services/Auth0AuthenticationService.cs
//   Features/Pages/PortalLogin/PortalLoginPageController.cs
//   Models/Auth0Models.cs

// ADD new files:
//   Features/Pages/PortalMfaChallenge/PortalMfaChallengePage.cs
//   Features/Pages/PortalMfaChallenge/PortalMfaChallengePageViewModel.cs
//   Features/Pages/PortalMfaChallenge/PortalMfaChallengePageController.cs
//   Features/Pages/PortalMfaChallenge/PortalMfaChallengePage.cshtml


// ------------------------------------------------------------
// 2. Auth0 DASHBOARD SETUP
// ------------------------------------------------------------

// A. Enable MFA factors:
//    Security → Multi-factor Auth
//    → Enable "Push" (Auth0 Guardian)
//    → Enable "One-time Password" (OTP fallback)
//    → Set policy to "Always"

// B. Enable MFA grant type on your application:
//    Applications → Your App → Settings
//    → Advanced Settings → Grant Types
//    → Tick "MFA"
//    → Save

// C. Guardian push requires the Auth0 Guardian app:
//    Users install Auth0 Guardian on their phone
//    and enrol on first login via Guardian enrollment flow


// ------------------------------------------------------------
// 3. CMS EDITOR — create the MFA page
// ------------------------------------------------------------

// Create a new page of type "Portal MFA Challenge Page"
// Set its URL to: /portal-mfa
// Publish it


// ------------------------------------------------------------
// 4. NO Program.cs CHANGES NEEDED
// ------------------------------------------------------------

// The existing PortalCookies cookie config and endpoint routing
// are unchanged. The new /portal-mfa/poll route is handled by
// the [HttpPost("portal-mfa/poll")] attribute on the controller.


// ------------------------------------------------------------
// 5. HOW THE FLOW WORKS
// ------------------------------------------------------------

// User submits email + password on /portal-login
//     ↓
// Auth0 returns mfa_required + mfa_token
//     ↓
// App calls /mfa/challenge (Guardian push)
//     ↓
//   ┌─ User enrolled?
//   │
//   │  YES → oob_code returned
//   │        Redirect to /portal-mfa
//   │        Page polls /portal-mfa/poll every 5s
//   │        User taps Allow in Guardian app
//   │        Poll returns tokens → sign in → /portal
//   │
//   │  NO  → association_required
//   │        Sign user in directly (first login, no MFA yet)
//   │        User will be prompted to enrol next time
//   └─
//
// OTP fallback:
//   User clicks "Use a code instead" on /portal-mfa
//   Enters 6-digit code from authenticator app
//   POST to /portal-mfa → VerifyMfaOtpAsync → sign in → /portal
