using EPiServer.Web;
using Knights.Web.Features.Pages.Portal.ViewModels;
using System.Security.Claims;

namespace Knights.Web.Features.Pages.Portal
{
    [Authorize(AuthenticationSchemes = "PortalCookies")]
    public class PortalPageController : PageController<PortalPage>
    {
        private readonly IContextModeResolver _contextMode;

        // IPortalUserContext removed — user info now comes from cookie claims
        public PortalPageController(IContextModeResolver contextMode)
        {
            _contextMode = contextMode;
        }

        public IActionResult Index(PortalPage currentContent)
        {
            var givenName  = User.FindFirstValue(ClaimTypes.GivenName) ?? string.Empty;
            var familyName = User.FindFirstValue(ClaimTypes.Surname)   ?? string.Empty;
            var fullName   = $"{givenName} {familyName}".Trim();

            var displayName = User.FindFirstValue(ClaimTypes.Name)
                           ?? (fullName.Length > 0 ? fullName : null)
                           ?? User.FindFirstValue(ClaimTypes.Email)
                           ?? "Portal User";

            var roles = User.FindAll(ClaimTypes.Role)
                            .Select(c => c.Value)
                            .ToList();

            return View("PortalPage", new PortalPageViewModel(currentContent)
            {
                DisplayName = displayName,
                Email       = User.FindFirstValue(ClaimTypes.Email) ?? string.Empty,
                Roles       = roles
            });
        }
    }
}
