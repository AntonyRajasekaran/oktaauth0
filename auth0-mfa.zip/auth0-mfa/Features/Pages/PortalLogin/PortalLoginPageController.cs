using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Services;

namespace Knights.Web.Features.Pages.PortalLogin;

public class PortalLoginPageController : PageController<PortalLoginPage>
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;

    public PortalLoginPageController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
    }

    [HttpGet]
    public IActionResult Index(PortalLoginPage currentContent)
    {
        if (User.Identity?.IsAuthenticated == true)
            return Redirect("/portal");

        var model = new PortalLoginPageViewModel(currentContent)
        {
            SuccessMessage = TempData["SignupSuccess"] as string
        };

        return View("PortalLoginPage", model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        PortalLoginPage currentContent, LoginInputModel input)
    {
        if (!ModelState.IsValid)
            return View("PortalLoginPage",
                new PortalLoginPageViewModel(currentContent));

        var (token, error, mfaToken) = await _auth0.LoginAsync(
            input.Email, input.Password);

        // ---------------------------------------------------------------
        // MFA required — Auth0 returned mfa_token instead of real tokens
        // ---------------------------------------------------------------
        if (error == "mfa_required")
        {
            // Request Guardian push challenge immediately
            var (challenge, challengeError) =
                await _auth0.RequestMfaChallengeAsync(mfaToken!);

            if (challengeError == "association_required")
            {
                // User not enrolled in MFA — Auth0 policy is set to skip
                // if not enrolled, so sign them in directly on first login.
                // They will be prompted to enrol in the Guardian app separately.
                var (loginToken, loginError, _) = await _auth0.LoginAsync(
                    input.Email, input.Password);

                if (loginError is not null && loginError != "mfa_required")
                    return View("PortalLoginPage",
                        new PortalLoginPageViewModel(currentContent)
                        {
                            ErrorMessage = loginError
                        });

                if (loginToken is not null)
                {
                    await SignInUserAsync(loginToken);
                    return Redirect("/portal");
                }
            }

            if (challengeError is not null)
                return View("PortalLoginPage",
                    new PortalLoginPageViewModel(currentContent)
                    {
                        ErrorMessage = challengeError
                    });

            // Store mfa_token and oob_code for the MFA challenge page
            TempData["MfaToken"] = mfaToken;
            TempData["OobCode"]  = challenge!.OobCode;

            return Redirect("/portal-mfa");
        }

        if (error is not null)
            return View("PortalLoginPage",
                new PortalLoginPageViewModel(currentContent)
                {
                    ErrorMessage = error
                });

        await SignInUserAsync(token!);
        return Redirect("/portal");
    }

    internal async Task SignInUserAsync(Auth0TokenResponse token)
    {
        var claims = _claimsService.ParseIdToken(token.IdToken);

        var authProperties = new AuthenticationProperties
        {
            IsPersistent = false,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        authProperties.StoreTokens(new[]
        {
            new AuthenticationToken
            {
                Name  = "access_token",
                Value = token.AccessToken
            }
        });

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            authProperties);
    }
}
