using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Knights.Web.Models;

namespace Knights.Web.Services;

public interface IAuth0AuthenticationService
{
    // Returns (Token, Error, MfaToken) — MfaToken is set when error == "mfa_required"
    Task<(Auth0TokenResponse? Token, string? Error, string? MfaToken)> LoginAsync(
        string email, string password);

    Task<(Auth0SignupResponse? User, string? Error)> SignupAsync(SignupRequest request);
    Task<(bool Success, string? Error)> ForgotPasswordAsync(string email);

    // MFA — Guardian push notification
    Task<(Auth0MfaChallengeResponse? Challenge, string? Error)> RequestMfaChallengeAsync(
        string mfaToken);
    Task<(Auth0TokenResponse? Token, string? Error)> PollMfaPushAsync(
        string mfaToken, string oobCode);

    // MFA — OTP fallback (authenticator app)
    Task<(Auth0TokenResponse? Token, string? Error)> VerifyMfaOtpAsync(
        string mfaToken, string otpCode);
}

public class Auth0AuthenticationService : IAuth0AuthenticationService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _config;
    private readonly ILogger<Auth0AuthenticationService> _logger;

    private string Domain       => _config["Auth0:Domain"]!;
    private string ClientId     => _config["Auth0:ClientId"]!;
    private string ClientSecret => _config["Auth0:ClientSecret"]!;
    private string Audience     => _config["Auth0:Audience"]!;
    private string Connection   => _config["Auth0:Connection"]
                                   ?? "Username-Password-Authentication";

    public Auth0AuthenticationService(
        HttpClient httpClient,
        IConfiguration config,
        ILogger<Auth0AuthenticationService> logger)
    {
        _httpClient = httpClient;
        _config     = config;
        _logger     = logger;
    }

    // -------------------------------------------------------------------------
    // LOGIN — Resource Owner Password Grant
    // Returns mfa_token when MFA is required instead of tokens
    // -------------------------------------------------------------------------
    public async Task<(Auth0TokenResponse? Token, string? Error, string? MfaToken)>
        LoginAsync(string email, string password)
    {
        var payload = new Dictionary<string, string>
        {
            ["grant_type"]    = "password",
            ["username"]      = email,
            ["password"]      = password,
            ["audience"]      = Audience,
            ["scope"]         = "openid profile email",
            ["client_id"]     = ClientId,
            ["client_secret"] = ClientSecret
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/oauth/token",
                new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0TokenResponse>(json);
                return (result, null, null);
            }

            // Check for mfa_required specifically — return mfa_token to caller
            var mfaResponse = JsonSerializer.Deserialize<Auth0MfaRequiredResponse>(json);
            if (mfaResponse?.Error == "mfa_required")
                return (null, "mfa_required", mfaResponse.MfaToken);

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [\"{Code}\"]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (null, errorMessage, null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 login request failed");
            return (null, "An unexpected error occurred. Please try again.", null);
        }
    }

    // -------------------------------------------------------------------------
    // SIGNUP — Auth0 DB Connection signup endpoint
    // -------------------------------------------------------------------------
    public async Task<(Auth0SignupResponse? User, string? Error)> SignupAsync(
        SignupRequest request)
    {
        var payload = new
        {
            client_id     = ClientId,
            email         = request.Email,
            password      = request.Password,
            connection    = Connection,
            name          = $"{request.GivenName} {request.FamilyName}",
            user_metadata = new
            {
                given_name  = request.GivenName,
                family_name = request.FamilyName
            }
        };

        try
        {
            var response = await _httpClient.PostAsJsonAsync(
                $"https://{Domain}/dbconnections/signup", payload);

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0SignupResponse>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [\"{Code}\"]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (default, errorMessage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 signup request failed");
            return (default, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // FORGOT PASSWORD
    // -------------------------------------------------------------------------
    public async Task<(bool Success, string? Error)> ForgotPasswordAsync(string email)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]  = ClientId,
            ["email"]      = email,
            ["connection"] = Connection
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/dbconnections/change_password",
                new FormUrlEncodedContent(payload));

            if (response.IsSuccessStatusCode) return (true, null);

            var error = await ParseErrorAsync(response);
            _logger.LogWarning("Auth0 forgot password error: {Error}", error);
            return (false, error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 forgot password request failed");
            return (false, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // REQUEST MFA CHALLENGE — asks Auth0 to send a Guardian push notification
    // Returns oob_code which the client uses when polling for push approval
    // Returns "association_required" error when user is not enrolled — caller
    // should handle this by signing the user in directly (skip MFA)
    // -------------------------------------------------------------------------
    public async Task<(Auth0MfaChallengeResponse? Challenge, string? Error)>
        RequestMfaChallengeAsync(string mfaToken)
    {
        var payload = new Dictionary<string, string>
        {
            ["client_id"]      = ClientId,
            ["client_secret"]  = ClientSecret,
            ["mfa_token"]      = mfaToken,
            ["challenge_type"] = "oob"   // Guardian push notification
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/mfa/challenge",
                new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0MfaChallengeResponse>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);

            // association_required = user not enrolled in MFA
            // Caller handles this by signing the user in directly
            if (errorResponse?.Error == "association_required")
                return (null, "association_required");

            return (null, MapError(errorResponse?.Error, errorResponse?.ErrorDescription));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 MFA challenge request failed");
            return (null, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // POLL FOR PUSH APPROVAL — called repeatedly until user approves/denies
    // Returns "authorization_pending" while waiting
    // Returns "slow_down" when Auth0 wants longer poll intervals
    // Returns "access_denied" when user denies the push
    // -------------------------------------------------------------------------
    public async Task<(Auth0TokenResponse? Token, string? Error)> PollMfaPushAsync(
        string mfaToken, string oobCode)
    {
        var payload = new Dictionary<string, string>
        {
            ["grant_type"]    = "http://auth0.com/oauth/grant-type/mfa-oob",
            ["client_id"]     = ClientId,
            ["client_secret"] = ClientSecret,
            ["mfa_token"]     = mfaToken,
            ["oob_code"]      = oobCode
        };

        try
        {
            var response = await _httpClient.PostAsync(
                $"https://{Domain}/oauth/token",
                new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Auth0TokenResponse>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);

            // Return these raw so the controller can handle polling logic
            if (errorResponse?.Error is "authorization_pending" or "slow_down"
                or "access_denied")
                return (null, errorResponse.Error);

            return (null, MapError(errorResponse?.Error, errorResponse?.ErrorDescription));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 MFA push poll failed");
            return (null, "An unexpected error occurred. Please try again.");
        }
    }

    // -------------------------------------------------------------------------
    // VERIFY OTP FALLBACK — user enters code from authenticator app
    // -------------------------------------------------------------------------
    public async Task<(Auth0TokenResponse? Token, string? Error)> VerifyMfaOtpAsync(
        string mfaToken, string otpCode)
    {
        var payload = new Dictionary<string, string>
        {
            ["grant_type"]    = "http://auth0.com/oauth/grant-type/mfa-otp",
            ["client_id"]     = ClientId,
            ["client_secret"] = ClientSecret,
            ["mfa_token"]     = mfaToken,
            ["otp"]           = otpCode
        };

        return await PostAsync<Auth0TokenResponse>(
            $"https://{Domain}/oauth/token", payload);
    }

    // -------------------------------------------------------------------------
    // Shared helpers
    // -------------------------------------------------------------------------
    private async Task<(T? Result, string? Error)> PostAsync<T>(
        string url, Dictionary<string, string> payload)
    {
        try
        {
            var response = await _httpClient.PostAsync(
                url, new FormUrlEncodedContent(payload));

            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<T>(json);
                return (result, null);
            }

            var errorResponse = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            var errorMessage  = MapError(errorResponse?.Error, errorResponse?.ErrorDescription);
            _logger.LogWarning("Auth0 error [\"{Code}\"]: {Desc}",
                errorResponse?.Error, errorResponse?.ErrorDescription);

            return (default, errorMessage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Auth0 API request to {Url} failed", url);
            return (default, "An unexpected error occurred. Please try again.");
        }
    }

    private static async Task<string> ParseErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var json  = await response.Content.ReadAsStringAsync();
            var error = JsonSerializer.Deserialize<Auth0ErrorResponse>(json);
            return MapError(error?.Error, error?.ErrorDescription);
        }
        catch
        {
            return "An unexpected error occurred.";
        }
    }

    private static string MapError(string? code, string? description) => code switch
    {
        "invalid_grant"          => "Incorrect email or password.",
        "invalid_user_password"  => "Incorrect email or password.",
        "too_many_attempts"      => "Account locked due to too many failed attempts. Check your email to unlock.",
        "user_exists"            => "An account with this email already exists.",
        "invalid_password"       => description ?? "Password does not meet requirements.",
        "invalid_signup"         => "Signup is not available at this time.",
        "unauthorized_client"    => "Authentication is not configured correctly.",
        "invalid_otp"            => "Incorrect code. Please try again.",
        "expired_token"          => "Your session has expired. Please sign in again.",
        // authorization_pending, slow_down, access_denied returned raw for polling logic
        "authorization_pending"  => "authorization_pending",
        "slow_down"              => "slow_down",
        "access_denied"          => "access_denied",
        _                        => "Something went wrong. Please try again."
    };
}
