using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Knights.Web.Services;

namespace Knights.Web.Features.Auth;

/// <summary>
/// Handles all portal authentication flows at /portal/auth/*.
///
/// Routed under /portal/auth to avoid colliding with the Optimizely
/// CMS content page at /portal served by PortalPageController.
///
/// Views are NOT resolved by the FeatureViewLocationExpander (which
/// only fires for controllers that have Properties["feature"] set —
/// none in this project do). ASP.NET Core's default view resolution
/// applies instead, so views live in /Views/PortalAuth/.
/// </summary>
[Route("portal/auth")]
public class PortalAuthController : Controller
{
    private readonly IAuth0AuthenticationService _auth0;
    private readonly IPortalClaimsService _claimsService;
    private readonly IConfiguration _config;

    public PortalAuthController(
        IAuth0AuthenticationService auth0,
        IPortalClaimsService claimsService,
        IConfiguration config)
    {
        _auth0         = auth0;
        _claimsService = claimsService;
        _config        = config;
    }

    // -------------------------------------------------------------------------
    // LOGIN  GET /portal/auth/login
    // -------------------------------------------------------------------------
    [HttpGet("login")]
    public IActionResult Login(string? returnUrl = null)
    {
        // Already authenticated — skip the login page
        if (User.Identity?.IsAuthenticated == true &&
            User.Identities.Any(i => i.AuthenticationType == "Auth0"))
            return RedirectToLocal(returnUrl);

        var model = new LoginViewModel
        {
            ReturnUrl      = returnUrl ?? "/portal",
            SuccessMessage = TempData["SignupSuccess"] as string
        };

        return View(model);
    }

    // POST /portal/auth/login
    [HttpPost("login")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var (token, error) = await _auth0.LoginAsync(model.Email, model.Password);

        if (error is not null)
        {
            model.ErrorMessage = error;
            return View(model);
        }

        var claims = _claimsService.ParseIdToken(token!.IdToken);

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            new AuthenticationProperties
            {
                IsPersistent = model.RememberMe,
                ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
            });

        return RedirectToLocal(model.ReturnUrl);
    }

    // -------------------------------------------------------------------------
    // SIGNUP  GET /portal/auth/signup
    // -------------------------------------------------------------------------
    [HttpGet("signup")]
    public IActionResult Signup() => View(new SignupViewModel());

    // POST /portal/auth/signup
    [HttpPost("signup")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Signup(SignupViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        // 1. Create the account in Auth0
        var (_, signupError) = await _auth0.SignupAsync(new SignupRequest(
            model.Email,
            model.Password,
            model.GivenName,
            model.FamilyName));

        if (signupError is not null)
        {
            model.ErrorMessage = signupError;
            return View(model);
        }

        // 2. Immediately log the user in after signup
        var (token, loginError) = await _auth0.LoginAsync(model.Email, model.Password);

        if (loginError is not null)
        {
            // Account created but auto-login failed — redirect to login with message
            TempData["SignupSuccess"] = "Account created successfully! Please sign in.";
            return RedirectToAction(nameof(Login));
        }

        var claims = _claimsService.ParseIdToken(token!.IdToken);

        await HttpContext.SignInAsync(
            "PortalCookies",
            new ClaimsPrincipal(new ClaimsIdentity(claims, "Auth0")),
            new AuthenticationProperties { IsPersistent = false });

        return RedirectToLocal("/portal");
    }

    // -------------------------------------------------------------------------
    // FORGOT PASSWORD  GET /portal/auth/forgot-password
    // -------------------------------------------------------------------------
    [HttpGet("forgot-password")]
    public IActionResult ForgotPassword() => View(new ForgotPasswordViewModel());

    // POST /portal/auth/forgot-password
    [HttpPost("forgot-password")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var (success, error) = await _auth0.ForgotPasswordAsync(model.Email);

        if (!success && error is not null)
        {
            // Only surface hard config-level errors.
            // Auth0 returns 200 for unknown emails to prevent enumeration.
            model.ErrorMessage = error;
            return View(model);
        }

        // Always show confirmation — never reveal whether the email exists
        model.EmailSent = true;
        return View(model);
    }

    // -------------------------------------------------------------------------
    // LOGOUT  POST /portal/auth/logout
    // -------------------------------------------------------------------------
    [HttpPost("logout")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync("PortalCookies");

        // End the Auth0 session to prevent silent re-authentication
        var domain   = _config["Auth0:Domain"];
        var clientId = _config["Auth0:ClientId"];
        var returnTo = Uri.EscapeDataString(
            $"{Request.Scheme}://{Request.Host}/portal/auth/login");

        return Redirect(
            $"https://{domain}/v2/logout?client_id={clientId}&returnTo={returnTo}");
    }

    // -------------------------------------------------------------------------
    // Helper
    // -------------------------------------------------------------------------
    private IActionResult RedirectToLocal(string? returnUrl)
    {
        if (Url.IsLocalUrl(returnUrl)) return LocalRedirect(returnUrl);
        return Redirect("/portal");
    }
}
