using System.Text.Json.Serialization;

namespace Knights.Web.Models;

public record LoginRequest(string Email, string Password);

public record SignupRequest(
    string Email,
    string Password,
    string GivenName,
    string FamilyName);

public record ForgotPasswordRequest(string Email);

public record Auth0TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; init; } = default!;

    [JsonPropertyName("id_token")]
    public string IdToken { get; init; } = default!;

    [JsonPropertyName("token_type")]
    public string TokenType { get; init; } = default!;

    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; init; }
}

public record Auth0ErrorResponse
{
    [JsonPropertyName("error")]
    public string Error { get; init; } = default!;

    [JsonPropertyName("error_description")]
    public string ErrorDescription { get; init; } = default!;
}

public record Auth0SignupResponse
{
    [JsonPropertyName("_id")]
    public string Id { get; init; } = default!;

    [JsonPropertyName("email")]
    public string Email { get; init; } = default!;

    [JsonPropertyName("email_verified")]
    public bool EmailVerified { get; init; }
}

// -------------------------------------------------------------------------
// MFA — Challenge / Login
// -------------------------------------------------------------------------

/// <summary>
/// Returned by Auth0 when MFA is required after password grant.
/// Contains the mfa_token needed for subsequent MFA calls.
/// </summary>
public record Auth0MfaRequiredResponse
{
    [JsonPropertyName("error")]
    public string Error { get; init; } = default!;

    [JsonPropertyName("mfa_token")]
    public string MfaToken { get; init; } = default!;
}

/// <summary>
/// Returned by Auth0 /mfa/challenge — contains oob_code for OTP polling.
/// </summary>
public record Auth0MfaChallengeResponse
{
    [JsonPropertyName("challenge_type")]
    public string ChallengeType { get; init; } = default!;

    // Required when verifying the OTP code
    [JsonPropertyName("oob_code")]
    public string? OobCode { get; init; }

    [JsonPropertyName("error")]
    public string? Error { get; init; }

    [JsonPropertyName("error_description")]
    public string? ErrorDescription { get; init; }
}

// -------------------------------------------------------------------------
// MFA — Enrolment (first-time setup during/after signup)
// -------------------------------------------------------------------------

/// <summary>
/// Returned by Auth0 /mfa/associate when enrolling a new MFA method.
/// Contains oob_code used to verify the enrolment OTP.
/// </summary>
public record Auth0MfaAssociateResponse
{
    // The out-of-band code — required when confirming enrolment OTP
    [JsonPropertyName("oob_code")]
    public string OobCode { get; init; } = default!;

    // "oob" for email/SMS
    [JsonPropertyName("authenticator_type")]
    public string AuthenticatorType { get; init; } = default!;

    // "email" or "sms"
    [JsonPropertyName("oob_channel")]
    public string? OobChannel { get; init; }

    // The phone number Auth0 will send SMS to (masked)
    [JsonPropertyName("recovery_codes")]
    public string[]? RecoveryCodes { get; init; }

    [JsonPropertyName("error")]
    public string? Error { get; init; }

    [JsonPropertyName("error_description")]
    public string? ErrorDescription { get; init; }
}

/// <summary>
/// MFA method chosen by the user at signup time.
/// </summary>
public enum MfaMethod
{
    Email,
    Sms
}
