using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.Extensions.Configuration;

namespace Knights.Web.Services;

public interface IPortalClaimsService
{
    IEnumerable<Claim> ParseIdToken(string idToken);
}

public class PortalClaimsService : IPortalClaimsService
{
    private readonly IConfiguration _config;

    // Must match the namespace set in your Auth0 Post-Login Action
    private string ClaimsNamespace => _config["Auth0:ClaimsNamespace"]
        ?? "https://yoursite.com/claims";

    public PortalClaimsService(IConfiguration config) => _config = config;

    public IEnumerable<Claim> ParseIdToken(string idToken)
    {
        var handler = new JwtSecurityTokenHandler();
        var jwt     = handler.ReadJwtToken(idToken);
        var claims  = new List<Claim>();

        // Map standard OIDC claims to ASP.NET Core claim types
        MapClaim(jwt, claims, "sub",         ClaimTypes.NameIdentifier);
        MapClaim(jwt, claims, "email",       ClaimTypes.Email);
        MapClaim(jwt, claims, "name",        ClaimTypes.Name);
        MapClaim(jwt, claims, "given_name",  ClaimTypes.GivenName);
        MapClaim(jwt, claims, "family_name", ClaimTypes.Surname);

        // Fallback: pull name from Auth0 Action custom claim if standard claim absent
        if (!claims.Any(c => c.Type == ClaimTypes.Name))
        {
            MapClaim(jwt, claims, $"{ClaimsNamespace}/name", ClaimTypes.Name);
        }

        // Map RBAC roles — Auth0 sends these as a JSON array via Post-Login Action
        var rolesClaim = jwt.Claims
            .FirstOrDefault(c => c.Type == $"{ClaimsNamespace}/roles");

        if (rolesClaim is not null)
        {
            var roles = JsonSerializer.Deserialize<string[]>(rolesClaim.Value)
                        ?? Array.Empty<string>();

            foreach (var role in roles)
                claims.Add(new Claim(ClaimTypes.Role, role));
        }

        return claims;
    }

    private static void MapClaim(
        JwtSecurityToken jwt,
        List<Claim> claims,
        string jwtClaimType,
        string aspnetClaimType)
    {
        var value = jwt.Claims.FirstOrDefault(c => c.Type == jwtClaimType)?.Value;
        if (value is not null)
            claims.Add(new Claim(aspnetClaimType, value));
    }
}
