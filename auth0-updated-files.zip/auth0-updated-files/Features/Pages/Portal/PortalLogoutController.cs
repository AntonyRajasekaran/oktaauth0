using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Knights.Web.Features.Pages.Portal
{
    [Authorize(AuthenticationSchemes = "PortalCookies")]
    [Route("portal")]
    [AutoValidateAntiforgeryToken]
    public class PortalLogoutController : Controller
    {
        private readonly IConfiguration _config;

        // IUrlResolver removed — returnTo URL is built directly from request context
        public PortalLogoutController(IConfiguration config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            // Clear the portal cookie
            await HttpContext.SignOutAsync("PortalCookies");

            // End the Auth0 session so the user cannot silently re-authenticate
            var domain   = _config["Auth0:Domain"];
            var clientId = _config["Auth0:ClientId"];
            var returnTo = Uri.EscapeDataString(
                $"{Request.Scheme}://{Request.Host}/portal/auth/login");

            return Redirect(
                $"https://{domain}/v2/logout?client_id={clientId}&returnTo={returnTo}");
        }
    }
}
