using System.ComponentModel.DataAnnotations;

namespace Knights.Web.Features.Auth;

public class SignupViewModel
{
    [Required, Display(Name = "First name")]
    public string GivenName { get; set; } = default!;

    [Required, Display(Name = "Last name")]
    public string FamilyName { get; set; } = default!;

    [Required, EmailAddress]
    public string Email { get; set; } = default!;

    [Required, MinLength(8), DataType(DataType.Password)]
    public string Password { get; set; } = default!;

    [Required, DataType(DataType.Password)]
    [Compare(nameof(Password), ErrorMessage = "Passwords do not match.")]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = default!;

    public string? ErrorMessage { get; set; }
}
