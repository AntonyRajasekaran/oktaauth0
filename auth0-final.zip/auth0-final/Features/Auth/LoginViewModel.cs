using System.ComponentModel.DataAnnotations;

namespace Knights.Web.Features.Auth;

public class LoginViewModel
{
    [Required, EmailAddress]
    public string Email { get; set; } = default!;

    [Required, DataType(DataType.Password)]
    public string Password { get; set; } = default!;

    [Display(Name = "Remember me")]
    public bool RememberMe { get; set; }

    public string? ReturnUrl      { get; set; }
    public string? ErrorMessage   { get; set; }
    public string? SuccessMessage { get; set; }
}
