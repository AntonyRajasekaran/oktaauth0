/**
 * Auth0 Post-Login Action
 *
 * Deploy in: Auth0 Dashboard → Actions → Library → Create Action
 * Then add to: Actions → Flows → Login
 *
 * Appends RBAC roles and display name to the id_token as namespaced
 * custom claims. The namespace must match Auth0:ClaimsNamespace in
 * appsettings.json.
 */

exports.onExecutePostLogin = async (event, api) => {
  const namespace = 'https://yoursite.com/claims';

  // Attach RBAC roles assigned in Auth0 Dashboard → User Management → Roles
  const roles = event.authorization?.roles ?? [];
  api.idToken.setCustomClaim(`${namespace}/roles`, roles);
  api.accessToken.setCustomClaim(`${namespace}/roles`, roles);

  // Attach display name as fallback for the .NET claims mapping
  if (event.user.name) {
    api.idToken.setCustomClaim(`${namespace}/name`, event.user.name);
  }
};
