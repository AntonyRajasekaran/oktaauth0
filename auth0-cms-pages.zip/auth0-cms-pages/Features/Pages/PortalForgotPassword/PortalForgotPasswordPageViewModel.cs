using System.ComponentModel.DataAnnotations;
using EPiServer.Web.Mvc;

namespace Knights.Web.Features.Pages.PortalForgotPassword;

public class PortalForgotPasswordPageViewModel : ContentViewModel<PortalForgotPasswordPage>
{
    public PortalForgotPasswordPageViewModel(PortalForgotPasswordPage currentContent)
        : base(currentContent) { }

    public bool    EmailSent    { get; set; }
    public string? Email        { get; set; }
    public string? ErrorMessage { get; set; }
}

public class ForgotPasswordInputModel
{
    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Enter a valid email address")]
    public string Email { get; set; } = default!;
}
